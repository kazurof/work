package primespiral;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintWriter;

public class GenJson {

    public static void main(String[] args) throws IOException {

        FileReader fr = new FileReader(new File("./primes1.txt"));
        BufferedReader br = new BufferedReader(fr);

        PrintWriter pw = new PrintWriter(new File("./prime.json"));

        pw.println("[ ");

        String line = null;
        int count = 0;
        while ((line = br.readLine()) != null) {
            if (line.length() == 0) {
                continue;
            }
            String[] primes = line.trim().split("\\s+");
            for (String prime : primes) {
                pw.println(prime + ",");
            }
            if (count % 10000 == 0) {
                System.out.println(count + " count");

            }
            count++;
            pw.flush();
        }
        pw.println("]");
        pw.flush();
        System.out.println("end " + count + " count");
    }
}
