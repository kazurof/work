/*
 *  $Id: Drawer.java 181 2011-12-03 17:02:41Z fukuhara $
 */
package primespiral;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics2D;
import java.awt.GraphicsEnvironment;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.geom.Rectangle2D;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;
import java.util.logging.Logger;

import javax.imageio.ImageIO;

import org.apache.commons.lang3.ArrayUtils;
import org.apache.commons.math.linear.Array2DRowRealMatrix;
import org.apache.commons.math.linear.RealMatrix;

import com.google.gson.Gson;

/**
 * @author fukuhara
 * 
 */
public class Drawer {
    static final Logger LOGGER = Logger.getLogger("Drawer");
    // for content enbeded image.
    // private static final int IMAGE_SIZE = 500;
    // private static final int MAGNIFY_LEVEL = 4;
    // private static final int RECTANGLE_SIZE = 3;
    // private static final int PRIME_THRESHOLD = 10000;

    // for linked large image.
    // private static final int IMAGE_SIZE = 2000;
    // private static final int MAGNIFY_LEVEL = 6;
    // private static final int RECTANGLE_SIZE = 4;
    // private static final int PRIME_THRESHOLD = 100000;

    // for movie image.
    /*
     * bit rate -- 720p 5,000 kbps 720p: 1280x720
     */
    private static final int IMAGE_SIZE_W = 640;
    private static final int IMAGE_SIZE_H = 360;
    // private static final int IMAGE_SIZE_W = 1280;
    // private static final int IMAGE_SIZE_H = 720;

    private static final int MAGNIFY_LEVEL = 8;
    private static final int RECTANGLE_SIZE = 6;
    private static final int PRIME_THRESHOLD = 100000;
    //
    static RealMatrix moveToZero = new Array2DRowRealMatrix(new double[] {
            (IMAGE_SIZE_W / 2) - (RECTANGLE_SIZE / 2), (IMAGE_SIZE_H / 2) - (RECTANGLE_SIZE / 2) });

    public static void main(String[] args) throws IOException {
        LOGGER.info("start");
        FileReader fr = new FileReader(new File("./prime.500000.json"));
        BufferedReader br = new BufferedReader(fr);
        StringBuilder sb = new StringBuilder();

        String line = null;
        while ((line = br.readLine()) != null) {
            sb.append(line);
        }

        Gson gson = new Gson();
        int[] primes = gson.fromJson(sb.toString(), int[].class);

        boolean[] primePos = new boolean[primes[primes.length - 1] + 1];

        for (int i = 0; i < primes.length && primes[i] < PRIME_THRESHOLD; i++) {
            primePos[primes[i]] = true;
        }

        boolean[] target = ArrayUtils.subarray(primePos, 0, ArrayUtils.lastIndexOf(primePos, true) - 1);
        // draw one image . simple prime spiral
        // drawOne(target, "primespiral-large-16x9.png" , 1);
        // System.out.println("end");

        // draw many of image. for animation .
        for (int i = 0; i < 4000; i++) {
            boolean[] phase = ArrayUtils.subarray(target, 0, i + 1);
            ArrayUtils.reverse(phase);
            drawOne(phase, String.format("./anime/prime-%04d.png", i), i);
            if (i % 100 == 0) {
                LOGGER.info("round " + i);
            }
        }

        LOGGER.info("end");
    }

    static void drawOne(boolean[] dotArray, String fileName, int step) throws IOException {
        BufferedImage bi = new BufferedImage(IMAGE_SIZE_W, IMAGE_SIZE_H, BufferedImage.TYPE_INT_BGR);

        Graphics2D drawTarget = bi.createGraphics();
        drawTarget.setPaint(Color.WHITE);

        Rectangle rec = new Rectangle(IMAGE_SIZE_W, IMAGE_SIZE_H);
        drawTarget.fill(rec);

        BasicStroke wideStroke = new BasicStroke(1.0f);
        drawTarget.setStroke(wideStroke);
        drawTarget.setPaint(Color.BLACK);
        for (int i = 1; i < dotArray.length; i++) {

            if (!dotArray[i]) {
                continue;
            }
            PointInHoneycomb point = new PointInHoneycomb(i);

            RealMatrix point2D = point.toPosition();
            point2D.multiplyEntry(1, 0, -1);
            point2D.multiplyEntry(0, 0, MAGNIFY_LEVEL);
            point2D.multiplyEntry(1, 0, MAGNIFY_LEVEL);

            point2D = point2D.add(moveToZero);
            double[] col = point2D.getColumn(0);

            Rectangle2D.Double pixel = new Rectangle2D.Double(col[0], col[1], RECTANGLE_SIZE, RECTANGLE_SIZE);
            drawTarget.fill(pixel);
        }
        double originX = moveToZero.getEntry(0, 0);
        double originY = moveToZero.getEntry(1, 0);
        Rectangle2D.Double origin = new Rectangle2D.Double(originX, originY, RECTANGLE_SIZE, RECTANGLE_SIZE);
        drawTarget.setPaint(Color.RED);
        drawTarget.fill(origin);

        drawTarget.setPaint(Color.BLACK);
        Rectangle2D.Double titleBorder = new Rectangle2D.Double(5, 8, 170, 40);
        drawTarget.fill(titleBorder);

        drawTarget.setPaint(Color.WHITE);
        Rectangle2D.Double titleback = new Rectangle2D.Double(7, 10, 166, 36);
        drawTarget.fill(titleback);

        drawTarget.setPaint(Color.BLACK);
        Font f = new Font("メイリオ", Font.PLAIN, 30);
        drawTarget.setFont(f);
        drawTarget.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING,
                RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        drawTarget.drawString(String.format("step %04d ", step), 14, 40);

        ImageIO.write(bi, "png", new File(fileName));

    }
}
