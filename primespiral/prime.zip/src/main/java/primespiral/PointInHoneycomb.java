// $Id: PointInHoneycomb.java 177 2011-11-26 09:16:42Z fukuhara $

package primespiral;

import org.apache.commons.math.linear.Array2DRowRealMatrix;
import org.apache.commons.math.linear.RealMatrix;

public class PointInHoneycomb {
    private static final RealMatrix[] ROTATE = new RealMatrix[6];

    private static final RealMatrix XY_HONEYCOMB;

    static {
        double temp = Math.sqrt(3) / 2;

        ROTATE[0] = new Array2DRowRealMatrix(2, 2);
        ROTATE[0].setRow(0, new double[] {1, 0 });
        ROTATE[0].setRow(1, new double[] {0, 1 });

        ROTATE[1] = new Array2DRowRealMatrix(2, 2);
        ROTATE[1].setRow(0, new double[] {0.5, -1 * temp });
        ROTATE[1].setRow(1, new double[] {temp, 0.5 });

        ROTATE[2] = new Array2DRowRealMatrix(2, 2);
        ROTATE[2].setRow(0, new double[] {-0.5, -1 * temp });
        ROTATE[2].setRow(1, new double[] {temp, -0.5 });

        ROTATE[3] = new Array2DRowRealMatrix(2, 2);
        ROTATE[3].setRow(0, new double[] {-1, 0 });
        ROTATE[3].setRow(1, new double[] {0, -1 });

        ROTATE[4] = new Array2DRowRealMatrix(2, 2);
        ROTATE[4].setRow(0, new double[] {-0.5, temp });
        ROTATE[4].setRow(1, new double[] {-1 * temp, -0.5 });

        ROTATE[5] = new Array2DRowRealMatrix(2, 2);
        ROTATE[5].setRow(0, new double[] {0.5, temp });
        ROTATE[5].setRow(1, new double[] {-1 * temp, 0.5 });

        XY_HONEYCOMB = new Array2DRowRealMatrix(2, 2);
        XY_HONEYCOMB.setRow(0, new double[] {1, -0.5 });
        XY_HONEYCOMB.setRow(1, new double[] {0, temp });
    }

    static int calcRound(int number) {
        return 3 * ((number * number) + number);
    }

    PointInHoneycomb(int number) {
        int base = 0;
        for (int i = 1; i < 1000000000; i++) {
            int prev = calcRound(i - 1);
            int next = calcRound(i);
            if (prev < number && number <= next) {
                base = prev;
                this.round = i;
                break;
            }
        }

        int target = number - base;
        this.plane = target / this.round;
        this.step = target % this.round;
        if (this.plane == 0) {
            this.plane = 6;
        }
    }

    /**
     * 1 <= plane <= 6.
     * */
    int plane;
    int round;
    int step;

    @Override
    public String toString() {
        return "PointInHoneycomb [plane=" + plane + ", round=" + round + ", step=" + step + "]";
    }

    /** return 1x2 matrix */
    RealMatrix toPosition() {
        RealMatrix thisPosition = new Array2DRowRealMatrix(new double[] {this.round, this.step });
        RealMatrix result = ROTATE[this.plane - 1].multiply(XY_HONEYCOMB).multiply(thisPosition);
        return result;
    }
}
